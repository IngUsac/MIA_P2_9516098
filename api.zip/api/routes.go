package api

import (
	"fmt"
	"net/http"
)

/*
EnableCORS

Middleware sencillo para permitir que el Frontend
React pueda consumir la API REST.
*/
func EnableCORS(handler http.Handler) http.Handler {

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		w.Header().Set(
			"Access-Control-Allow-Origin",
			"http://localhost:3000",
		)

		w.Header().Set(
			"Access-Control-Allow-Methods",
			"GET, POST, OPTIONS",
		)

		w.Header().Set(
			"Access-Control-Allow-Headers",
			"Content-Type",
		)

		if r.Method == http.MethodOptions {

			w.WriteHeader(http.StatusOK)
			return

		}

		handler.ServeHTTP(w, r)

	})

}
func StartServer() {

	// Estado del Backend
	http.HandleFunc("/api/status", StatusHandler)

	// Intérprete de comandos
	http.HandleFunc("/api/execute", GenericCommandHandler)

	// Visualizador - Discos
	http.HandleFunc("/api/disks", GetDisksHandler)

	// Visualizador - Particiones
	http.HandleFunc("/api/partitions", GetPartitionsHandler)

	fmt.Println()
	fmt.Println("========================================")
	fmt.Println(" PROYECTO 1 - BACKEND REST")
	fmt.Println("========================================")
	fmt.Println("Puerto : 8080")
	fmt.Println("URL    : http://localhost:8080")
	fmt.Println()

	err := http.ListenAndServe(
		":8080",
		EnableCORS(http.DefaultServeMux),
	)

	if err != nil {
		fmt.Println("ERROR iniciando servidor:", err)
	}
}